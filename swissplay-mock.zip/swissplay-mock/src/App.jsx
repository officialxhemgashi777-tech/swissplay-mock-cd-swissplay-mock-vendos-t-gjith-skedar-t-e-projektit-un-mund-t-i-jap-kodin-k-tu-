import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import Header from './components/Header'
import Login from './pages/Login'
import Users from './pages/Users'
import UserDetail from './pages/UserDetail'

export default function App() {
  // simple auth stub: use localStorage flag
  const isLoggedIn = !!localStorage.getItem('mock_logged_in')

  if (!isLoggedIn) {
    return <Login />
  }

  return (
    <div className="app">
      <Sidebar />
      <div className="main">
        <Header />
        <div className="content">
          <Routes>
            <Route path="/" element={<Navigate to="/users" replace />} />
            <Route path="/users" element={<Users />} />
            <Route path="/users/:id" element={<UserDetail />} />
            <Route path="*" element={<div>Not found</div>} />
          </Routes>
        </div>
      </div>
    </div>
  )
}
