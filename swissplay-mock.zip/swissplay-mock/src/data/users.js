// mock user data — replace or connect to real API in future
const users = Array.from({length: 58}).map((_, i) => {
  const id = (i+1).toString()
  const statuses = ['active','suspended','pending']
  const status = statuses[Math.floor(Math.random()*statuses.length)]
  const balances = (Math.random()*2000).toFixed(2)
  return {
    id,
    username: `user${id}`,
    email: `user${id}@example.com`,
    status,
    balance: Number(balances),
    createdAt: new Date(Date.now() - Math.floor(Math.random()*1000*60*60*24*365)).toISOString().slice(0,10)
  }
})

export default users
