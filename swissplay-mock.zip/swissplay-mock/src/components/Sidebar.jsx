import React from 'react'
import { NavLink } from 'react-router-dom'

export default function Sidebar(){
  const onLogout = () => {
    localStorage.removeItem('mock_logged_in')
    window.location.reload()
  }
  return (
    <aside className="sidebar">
      <div className="brand">SwissPlay — Mock</div>
      <nav className="nav">
        <NavLink to="/users" className={({isActive}) => isActive ? 'active' : ''}>Users</NavLink>
        <NavLink to="/reports" className={({isActive}) => isActive ? 'active' : ''}>Reports</NavLink>
        <NavLink to="/bets" className={({isActive}) => isActive ? 'active' : ''}>Bets</NavLink>
      </nav>

      <div style={{marginTop:20}}>
        <button style={{padding:'8px 10px',borderRadius:8,border:'none',cursor:'pointer'}} onClick={onLogout}>Logout</button>
      </div>
    </aside>
  )
}
