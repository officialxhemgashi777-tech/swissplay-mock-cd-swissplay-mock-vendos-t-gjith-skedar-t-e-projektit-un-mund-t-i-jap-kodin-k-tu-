import React from 'react'
import { useNavigate } from 'react-router-dom'

export default function Header(){
  const navigate = useNavigate()
  return (
    <header className="header">
      <div style={{display:'flex',gap:12,alignItems:'center'}}>
        <div style={{fontWeight:700}}>Dashboard</div>
        <div className="search">
          <input placeholder="Search users, emails or ids..." onKeyDown={(e)=>{
            if(e.key === 'Enter'){
              // quick global search -> go to users with query param (not implemented)
              navigate('/users')
            }
          }} />
        </div>
      </div>

      <div style={{display:'flex',gap:12,alignItems:'center'}}>
        <div style={{textAlign:'right'}}>
          <div style={{fontSize:12,color:'#99a3b8'}}>Admin</div>
          <div style={{fontWeight:700}}>mock_admin</div>
        </div>
      </div>
    </header>
  )
}
