import React from 'react'

export default function Pagination({page, totalPages, onChange}) {
  const prev = () => onChange(Math.max(1, page-1))
  const next = () => onChange(Math.min(totalPages, page+1))
  return (
    <div style={{display:'flex',gap:8,alignItems:'center'}}>
      <button onClick={prev} disabled={page===1}>Prev</button>
      <div>Page {page} / {totalPages}</div>
      <button onClick={next} disabled={page===totalPages}>Next</button>
    </div>
  )
}
