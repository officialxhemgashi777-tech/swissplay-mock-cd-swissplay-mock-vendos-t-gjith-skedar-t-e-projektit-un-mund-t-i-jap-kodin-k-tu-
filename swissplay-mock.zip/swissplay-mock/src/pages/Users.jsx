import React, {useMemo, useState} from 'react'
import usersData from '../data/users'
import { Link, useSearchParams } from 'react-router-dom'
import Pagination from '../components/Pagination'

export default function Users(){
  const [searchParams, setSearchParams] = useSearchParams()
  const q = searchParams.get('q') || ''
  const [query,setQuery] = useState(q)
  const [status,setStatus] = useState('')
  const [sort,setSort] = useState('newest')
  const [page, setPage] = useState(1)
  const perPage = 10

  const filtered = useMemo(() => {
    let arr = usersData.slice()
    if(query.trim()){
      const L = query.toLowerCase()
      arr = arr.filter(u => u.username.toLowerCase().includes(L) || u.email.toLowerCase().includes(L) || u.id === query)
    }
    if(status) arr = arr.filter(u => u.status === status)
    if(sort === 'newest') arr.sort((a,b)=> b.id - a.id)
    if(sort === 'balance_desc') arr.sort((a,b)=> b.balance - a.balance)
    if(sort === 'balance_asc') arr.sort((a,b)=> a.balance - b.balance)
    return arr
  },[query,status,sort])

  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage))
  const shown = filtered.slice((page-1)*perPage, page*perPage)

  return (
    <div>
      <div className="panel">
        <h2>Users</h2>
        <div className="controls">
          <input placeholder="Search username or email..." value={query} onChange={e=>setQuery(e.target.value)} />
          <select value={status} onChange={e=>setStatus(e.target.value)}>
            <option value="">All statuses</option>
            <option value="active">Active</option>
            <option value="suspended">Suspended</option>
            <option value="pending">Pending</option>
          </select>
          <select value={sort} onChange={e=>setSort(e.target.value)}>
            <option value="newest">Newest</option>
            <option value="balance_desc">Balance: High → Low</option>
            <option value="balance_asc">Balance: Low → High</option>
          </select>
          <div style={{flex:1}} />
          <button onClick={()=>{ setPage(1); setSearchParams(query ? {q:query} : {})}}>Apply</button>
        </div>

        <div style={{overflowX:'auto'}}>
          <table className="table">
            <thead>
              <tr>
                <th>ID</th>
                <th>User</th>
                <th>Email</th>
                <th>Balance</th>
                <th>Status</th>
                <th>Joined</th>
              </tr>
            </thead>
            <tbody>
              {shown.map(u => (
                <tr className="user-row" key={u.id}>
                  <td>{u.id}</td>
                  <td><Link to={`/users/${u.id}`} style={{color:'inherit',textDecoration:'none'}}>{u.username}</Link></td>
                  <td>{u.email}</td>
                  <td>${u.balance.toFixed(2)}</td>
                  <td><span className={`badge ${u.status==='active' ? 'green' : u.status==='pending' ? 'yellow' : ''}`}>{u.status}</span></td>
                  <td>{u.createdAt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="footer-row">
          <div>{filtered.length} users</div>
          <Pagination page={page} totalPages={totalPages} onChange={(p)=>setPage(p)} />
        </div>
      </div>

      <div className="panel">
        <h2>Quick user cards</h2>
        <div className="card-grid">
          {shown.map(u => (
            <div className="user-card" key={'card'+u.id}>
              <h3>{u.username}</h3>
              <div className="user-meta">ID: {u.id} • {u.email}</div>
              <div style={{marginTop:8}}>
                <strong>${u.balance.toFixed(2)}</strong> <span style={{marginLeft:8}} className={`badge ${u.status==='active' ? 'green' : u.status==='pending' ? 'yellow' : ''}`}>{u.status}</span>
              </div>
              <div style={{marginTop:10}}>
                <Link to={`/users/${u.id}`}>View profile</Link>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
