import React, {useState} from 'react'

export default function Login(){
  const [user,setUser] = useState('')
  const [pass,setPass] = useState('')

  const login = (e) => {
    e.preventDefault()
    // demo auth
    localStorage.setItem('mock_logged_in','1')
    window.location.reload()
  }

  return (
    <div style={{height:'100vh',display:'flex',alignItems:'center',justifyContent:'center'}}>
      <div style={{width:420,background:'rgba(255,255,255,0.02)',padding:24,borderRadius:12}}>
        <h2 style={{marginTop:0}}>Admin Login — Mock</h2>
        <form onSubmit={login}>
          <div style={{marginBottom:8}}>
            <input placeholder="Username" value={user} onChange={e=>setUser(e.target.value)} style={{width:'100%',padding:10,borderRadius:8,background:'transparent',border:'1px solid rgba(255,255,255,0.04)',color:'white'}} />
          </div>
          <div style={{marginBottom:12}}>
            <input placeholder="Password" type="password" value={pass} onChange={e=>setPass(e.target.value)} style={{width:'100%',padding:10,borderRadius:8,background:'transparent',border:'1px solid rgba(255,255,255,0.04)',color:'white'}} />
          </div>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <button type="submit" style={{padding:'8px 12px',borderRadius:8}}>Sign in</button>
            <div style={{color:'#98a0b3',fontSize:13}}>Demo only — no real auth</div>
          </div>
        </form>
      </div>
    </div>
  )
}
