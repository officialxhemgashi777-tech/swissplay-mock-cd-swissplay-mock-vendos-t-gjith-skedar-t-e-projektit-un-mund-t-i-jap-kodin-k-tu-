import React from 'react'
import { useParams, Link } from 'react-router-dom'
import usersData from '../data/users'

export default function UserDetail(){
  const { id } = useParams()
  const user = usersData.find(u => u.id === id)
  if(!user) return <div className="panel"><h2>User not found</h2><Link to="/users">Back to users</Link></div>

  return (
    <div>
      <div className="panel">
        <h2>{user.username} <span style={{fontSize:13, color:'#98a0b3'}}>ID: {user.id}</span></h2>
        <div style={{display:'flex',gap:24,alignItems:'flex-start',flexWrap:'wrap'}}>
          <div style={{minWidth:260}}>
            <div style={{background:'rgba(255,255,255,0.02)',padding:12,borderRadius:8}}>
              <div style={{fontSize:13,color:'#98a0b3'}}>Email</div>
              <div style={{fontWeight:700}}>{user.email}</div>

              <div style={{marginTop:12,fontSize:13,color:'#98a0b3'}}>Status</div>
              <div style={{marginTop:6}}><span className={`badge ${user.status==='active' ? 'green' : user.status==='pending' ? 'yellow' : ''}`}>{user.status}</span></div>

              <div style={{marginTop:12,fontSize:13,color:'#98a0b3'}}>Balance</div>
              <div style={{marginTop:6,fontWeight:700}}>${user.balance.toFixed(2)}</div>
            </div>
          </div>

          <div style={{flex:1}}>
            <div style={{marginBottom:8}}>Recent activity (mock)</div>
            <div style={{background:'rgba(255,255,255,0.02)',padding:12,borderRadius:8}}>
              <ul style={{margin:0,paddingLeft:16}}>
                <li>Placed bet #A{user.id} — $12.00 — <span style={{color:'#98a0b3'}}>won</span></li>
                <li>Deposit — $50.00 — <span style={{color:'#98a0b3'}}>completed</span></li>
                <li>Login from new device — <span style={{color:'#98a0b3'}}>2 days ago</span></li>
              </ul>
            </div>
          </div>
        </div>

        <div style={{marginTop:12}}>
          <Link to="/users">← Back to users</Link>
        </div>
      </div>
    </div>
  )
}
